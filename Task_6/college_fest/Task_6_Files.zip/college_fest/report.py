
from pathlib import Path

def generate_reports(master, event_lists, errors):
    output = Path("output")
    output.mkdir(exist_ok=True)

    with open(output / "master_list.txt", "w", encoding="utf-8") as file:
        for student in master:
            file.write(
                f"{student['register_number']},"
                f"{student['name']},"
                f"{student['department']},"
                f"{student['email']}\n"
            )

    for event, students in event_lists.items():
        safe_name = "".join(
            c if c.isalnum() or c in "_-" else "_"
            for c in event
        )
        with open(output / f"{safe_name}_participants.txt",
                  "w", encoding="utf-8") as file:
            for student in students:
                file.write(
                    f"{student['register_number']},"
                    f"{student['name']},"
                    f"{student['department']}\n"
                )

    with open(output / "summary_report.txt", "w", encoding="utf-8") as file:
        file.write(f"Total valid registrations: {len(master)}\n")
        file.write(f"Total events: {len(event_lists)}\n")
        for event, students in event_lists.items():
            file.write(f"{event}: {len(students)} participants\n")

    with open(output / "error_log.txt", "w", encoding="utf-8") as file:
        if errors:
            file.write("\n".join(errors))
        else:
            file.write("No errors found.")
