
from .processor import process_files
from .report import generate_reports

def main():
    department_files = [
        "input/cse.txt",
        "input/it.txt",
        "input/aiml.txt",
        "input/ece.txt",
        "input/mech.txt"
    ]

    master, events, errors = process_files(department_files)
    generate_reports(master, events, errors)

    print("COLLEGE FEST REGISTRATION RESULTS")
    print("Valid registrations:", len(master))
    print("Events generated:", len(events))
    print("Errors recorded:", len(errors))
    print("Reports saved in the output folder.")

if __name__ == "__main__":
    main()
