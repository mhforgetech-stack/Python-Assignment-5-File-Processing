
def validate_record(line):
    fields = [item.strip() for item in line.strip().split(",")]

    if len(fields) != 5:
        raise ValueError("Record must contain exactly 5 fields")

    reg, name, department, email, events = fields

    if not all([reg, name, department, email, events]):
        raise ValueError("One or more fields are empty")

    if " " in email or email.count("@") != 1:
        raise ValueError("Invalid email address")

    local, domain = email.split("@")

    if not local or "." not in domain or domain.startswith(".") or domain.endswith("."):
        raise ValueError("Invalid email address")

    return {
        "register_number": reg,
        "name": name,
        "department": department,
        "email": email,
        "events": [e.strip() for e in events.split(";") if e.strip()]
    }
