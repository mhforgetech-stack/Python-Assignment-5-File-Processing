
def read_department_file(filename):
    with open(filename, "r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            yield line_number, line
