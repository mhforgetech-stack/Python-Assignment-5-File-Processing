
from .reader import read_department_file
from .validator import validate_record

def process_files(files):
    master = []
    seen = set()
    event_lists = {}
    errors = []

    for filename in files:
        try:
            for line_number, line in read_department_file(filename):
                try:
                    student = validate_record(line)

                    reg = student["register_number"]

                    if reg in seen:
                        raise ValueError("Duplicate registration number")

                    seen.add(reg)
                    master.append(student)

                    for event in student["events"]:
                        event_lists.setdefault(event, []).append(student)

                except ValueError as error:
                    errors.append(
                        f"{filename}, line {line_number}: {error}"
                    )

        except FileNotFoundError:
            errors.append(f"{filename}: Department file not found")

        except PermissionError:
            errors.append(f"{filename}: Permission denied")

        except UnicodeDecodeError:
            errors.append(f"{filename}: Encoding error")

    return master, event_lists, errors
